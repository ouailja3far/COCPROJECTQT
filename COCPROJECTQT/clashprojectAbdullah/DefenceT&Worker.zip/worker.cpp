#include "worker.h"
#include <QDebug>

Worker::Worker(QObject *parent) : QObject(parent)
{
    m_health = 100;
    m_position = QPoint(0, 0);
    m_target = QPoint(-1, -1);
}

void Worker::move(QPoint target)
{
    qDebug() << "moving worker to repair:" << target << "...";
    m_target = target;
}

void Worker::repair()
{
    // tmp worker repair logic
    if (m_target != QPoint(-1, -1)) {
        qDebug() << "repairing:" << m_target << "...";
        qDebug() << "Repair complete!";
    } else {
        qDebug() << "No target to repair!";
    }
}
