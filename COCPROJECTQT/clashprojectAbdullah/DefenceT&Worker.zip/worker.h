#ifndef WORKER_H
#define WORKER_H

#include <QObject>
#include <QPoint>

class Worker : public QObject
{
    Q_OBJECT

public:
    explicit Worker(QObject *parent = nullptr);

    void move(QPoint target);
    void repair();

private:
    int m_health;
    QPoint m_position;
    QPoint m_target;
};

#endif
