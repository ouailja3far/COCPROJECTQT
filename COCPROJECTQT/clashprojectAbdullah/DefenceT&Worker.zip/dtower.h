#ifndef DTOWER_H
#define DTOWER_H

#include <QObject>
#include <QPoint>

class DTower : public QObject
{
    Q_OBJECT

public:
    explicit DTower(QObject *parent = nullptr);

    void aimAndShoot(QString target);
    void upgradeDamage();

signals:
    void shooting(QString target, int damage);

private:
    QString m_type;// cannon ,archer or wizard
    int m_damage;
    QPoint m_position;
};

#endif // DTOWER_H
